<?php
$servidor = "http://localhost";
$localMysql = "localhost";
$usuarioMySql = "root";
$senhaMySql = "";
$bancoDeDados = "site";




//$servidor = "igorlisboa.esy.es";
//$localMysql = "mysql.hostinger.com.br";
//$usuarioMySql = "u354548780_root";
//$senhaMySql = "446758";
//$bancoDeDados = "u354548780_dbtst";


?>