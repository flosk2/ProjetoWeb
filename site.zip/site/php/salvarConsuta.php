<?php
include 'db.php';


$clinica = $_POST['clinica'];
$valor = "250";
$tipo = $_POST['especializao'];
$telefone = $_POST['fone'];
$data = $_POST['data'];



//$clinica = "fdgdfg";
//$valor = "fdgdfg";
//$tipo = "fdgdfg";
//$telefone = "fdgdfg";

$sql = "INSERT INTO consultas_usuario (data,clinica,valor,tipo,telefone)VALUES('$data','$clinica','$valor','$tipo','$telefone');";

if ($conn->query($sql) === TRUE) {
    //echo "New record created successfully";
	
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
	echo "ssdd";
}

$conn->close();




?>

